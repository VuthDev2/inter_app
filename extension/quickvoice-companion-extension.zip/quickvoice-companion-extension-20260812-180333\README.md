# QuickVoice Companion Chrome Extension

This extension connects Chrome to the local QuickVoice project.

## Features

- Open the QuickVoice web app at `http://localhost:3000`
- Open the Expo web app at `http://localhost:8083`
- Sign in or sign up with the same Supabase project
- Continue with Google by opening the web login page
- Open a Chrome side panel with translation and recording tools
- Translate selected webpage text from the right-click menu
- Record microphone audio and send it to the backend `/transcribe` endpoint

## Load in Chrome

1. Open `chrome://extensions`.
2. Enable `Developer mode`.
3. Click `Load unpacked`.
4. Select this folder:

   `C:\Users\thyt6\Documents\inter_app-git\extension`

The packaged clean copy is available at:

`C:\Users\thyt6\Documents\inter_app-git\extension-clean\quickvoice-companion`

The ZIP package is:

`C:\Users\thyt6\Documents\inter_app-git\QuickVoice-Companion-extension.zip`

## Before Using

Keep these running:

- Backend: `http://localhost:8000`
- Web: `http://localhost:3000`
- App: `http://localhost:8083`

The first time you record audio, Chrome will ask for microphone permission.

## Invalid Credentials

`Invalid credentials` means Supabase rejected that email/password pair. Use the password for the QuickVoice account itself. Gmail app passwords are only for the backend email sender and cannot log in. If the account was created with Google, use the web Google login or reset/create a password first.
